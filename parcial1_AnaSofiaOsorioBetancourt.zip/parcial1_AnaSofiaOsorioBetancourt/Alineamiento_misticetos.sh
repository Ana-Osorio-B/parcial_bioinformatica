#!/bin/bash
#SBATCH	-p normal
#SBATCH	-N 1
#SBATCH	-n 10
#SBATCH	-t 0-00:20
#SBATCH	-o alineamiento_muscle.out
#SBATCH	-e alineamiento_muscle.err

module load muscle/3.8.31
muscle -in sequence_misticetos2.fasta -out misticetos_muscle.fasta
